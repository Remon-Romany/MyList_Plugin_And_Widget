# myList Plugin Wordpress Widget

Widget to display and can add items to the list, the List can be simply , When you add widgets to any page, it will be replaced by a list of items inserted from widgets list. Simply display the list of items.

### Version
1.0.0