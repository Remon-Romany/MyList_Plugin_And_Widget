<?php

//silence is golden